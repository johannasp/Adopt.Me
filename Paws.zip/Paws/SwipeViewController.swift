//
//  SwipeViewController.swift
//  Paws
//
//  Created by Justin Shillingford on 1/28/17.
//  Copyright © 2017 Pursuit of Appiness LLC. All rights reserved.
//

import UIKit
import FacebookLogin
import Firebase
import FacebookCore

let credential = FIRFacebookAuthProvider.credential(withAccessToken: (AccessToken.current?.authenticationToken)!)

class SwipeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
		
		view.backgroundColor = .white
		
		let welcomeUILabel = UILabel(frame: CGRect(x: 0, y: view.center.y - 75, width: view.frame.width, height: 50))
		welcomeUILabel.center.x = view.center.x
		welcomeUILabel.text = "Welcome to Adopt.me."
		welcomeUILabel.textAlignment = .center
		welcomeUILabel.textColor = .black
		view.addSubview(welcomeUILabel)
		
		let differenceUILabel = UILabel(frame: CGRect(x: 0, y: view.center.y - 50, width: view.frame.width, height: 50))
		differenceUILabel.center.x = view.center.x
		differenceUILabel.text = "Ready to make a difference?"
		differenceUILabel.textAlignment = .center
		differenceUILabel.textColor = .black
		view.addSubview(differenceUILabel)
		
		let loginButton = LoginButton(readPermissions: [ .publicProfile ])
		loginButton.center.x = view.center.x
		loginButton.center.y = view.center.y
		loginButton.delegate? = self as! LoginButtonDelegate
		view.addSubview(loginButton)
		
		//credential = FIRFacebookAuthProvider.credential(withAccessToken: (AccessToken.current?.authenticationToken)!)
		
		FIRAuth.auth()?.signIn(with: credential) { (user, error) in
			// ...
			if let error = error {
				// ...
				return
			}
		
		
		//TinderFeedViewController.swift
		
    }
	
	func loginButton(loginButton: LoginButton!, didCompleteWithResult result: LoginManager!, error: NSError?) {
  if let error = error {
	print(error.localizedDescription)
	return
  }
  // ...
	}

}
}
